build_iozone() {    
    set -e
    ARCH=`uname -i`
    mntpath="/tmp/sdb"
    if [ ! -d $mntpath ]
    then
        mkdir -p $mntpath
    fi
    myOBJPATH=/tmp/sdb/
    if [ $ARCH = "x86_64" ]
    then
        make linux-AMD64 -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    elif [ $ARCH = "x86_32" ]; then
        make linux -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    else
        make linux-arm -s
        cp iozone $myOBJPATH
        cp fileop $myOBJPATH
    fi
}

build_iozone
